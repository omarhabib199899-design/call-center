/**
 * [CUSTOM] Keeps a signed-in panel user off the login screen.
 *
 * The compiled panel's login routes don't check for an existing session, so
 * pressing Back from the inbox lands on /agent/login and shows the sign-in
 * form even though the token in localStorage is still valid. Agents read that
 * as being logged out and sign in again, mid-conversation.
 *
 * This guard runs on the login routes only. If a token is present it verifies
 * it against the API first, then sends the person back to their panel. An
 * invalid token is cleared so the login form behaves normally — that check is
 * what stops a redirect loop.
 */
(function () {
  "use strict";

  var PANELS = [
    { path: "/agent/login", key: "wacrm_agent", verify: "/api/agent/get_me", home: "/agent" },
    { path: "/user/login", key: "wacrm_user", verify: "/api/user/get_me", home: "/user" },
    { path: "/admin/login", key: "wacrm_admin", verify: "/api/admin/get_admin", home: "/admin" },
  ];

  var checking = false;

  function currentPanel() {
    var p = location.pathname.replace(/\/+$/, "").toLowerCase();
    for (var i = 0; i < PANELS.length; i++) {
      if (p === PANELS[i].path) return PANELS[i];
    }
    return null;
  }

  function read(key) {
    try {
      return localStorage.getItem(key) || "";
    } catch (e) {
      return "";
    }
  }

  function clear(key) {
    try {
      localStorage.removeItem(key);
    } catch (e) {}
  }

  function guard() {
    if (checking) return;

    var panel = currentPanel();
    if (!panel) return;

    var token = read(panel.key);
    if (!token) return; // no session — leave the login form alone

    checking = true;

    fetch(panel.verify, {
      headers: { Authorization: "Bearer " + token },
    })
      .then(function (r) {
        return r.json().catch(function () {
          return null;
        });
      })
      .then(function (d) {
        if (d && d.success) {
          // Replace, not push, so Back doesn't bounce between the two.
          location.replace(panel.home);
          return;
        }
        // Token is dead — drop it and let the person sign in normally.
        clear(panel.key);
        checking = false;
      })
      .catch(function () {
        // Network trouble: do nothing rather than trap someone on a blank page.
        checking = false;
      });
  }

  function start() {
    guard();

    ["pushState", "replaceState"].forEach(function (fn) {
      var original = history[fn];
      history[fn] = function () {
        var result = original.apply(this, arguments);
        setTimeout(guard, 0);
        return result;
      };
    });

    window.addEventListener("popstate", function () {
      setTimeout(guard, 0);
    });

    window.addEventListener("pageshow", function (e) {
      if (e.persisted) guard(); // back/forward cache
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
