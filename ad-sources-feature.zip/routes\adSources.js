/**
 * Click-to-WhatsApp ad attribution report.
 *
 * Owner-only. Serves the page at /ad-sources.html.
 */

const express = require("express");
const router = express.Router();

const { query } = require("../database/dbpromise");
const validateUser = require("../middlewares/user");
const logger = require("../utils/logger");

const MISSING =
  "Table chat_ad_source is missing. Run database/chat_ad_source.sql first.";

function fail(res, err) {
  logger.log(err);
  res.json({
    success: false,
    msg: err?.code === "ER_NO_SUCH_TABLE" ? MISSING : "something went wrong",
  });
}

/** Days filter -> SQL fragment. 0 / missing means all time. */
function sinceClause(days) {
  const n = parseInt(days, 10);
  return Number.isFinite(n) && n > 0
    ? { sql: ` AND createdAt >= DATE_SUB(NOW(), INTERVAL ? DAY)`, params: [n] }
    : { sql: "", params: [] };
}

/** One row per ad: how many distinct customers it brought. */
router.get("/summary", validateUser, async (req, res) => {
  try {
    const uid = req.decode.uid;
    const since = sinceClause(req.query.days);

    const rows = await query(
      `SELECT
         source_id,
         MAX(ad_title)    AS ad_title,
         MAX(source_url)  AS source_url,
         MAX(source_type) AS source_type,
         MAX(origin)      AS origin,
         COUNT(DISTINCT chat_id) AS customers,
         MIN(createdAt)   AS first_seen,
         MAX(createdAt)   AS last_seen
       FROM chat_ad_source
       WHERE uid = ?${since.sql}
       GROUP BY source_id
       ORDER BY customers DESC, last_seen DESC`,
      [uid, ...since.params],
    );

    const total = rows.reduce((n, r) => n + Number(r.customers || 0), 0);

    res.json({ success: true, data: { ads: rows, total } });
  } catch (err) {
    fail(res, err);
  }
});

/** The customers themselves, newest first. Optionally one ad only. */
router.get("/contacts", validateUser, async (req, res) => {
  try {
    const uid = req.decode.uid;
    const since = sinceClause(req.query.days);

    const params = [uid, ...since.params];
    let adFilter = "";

    if (req.query.source_id) {
      adFilter = " AND source_id = ?";
      params.push(String(req.query.source_id));
    }

    const limit = Math.min(parseInt(req.query.limit, 10) || 500, 2000);

    const rows = await query(
      `SELECT sender_mobile, sender_name, chat_id, source_id, ad_title,
              source_url, source_type, origin, createdAt
         FROM chat_ad_source
        WHERE uid = ?${since.sql}${adFilter}
        ORDER BY createdAt DESC
        LIMIT ?`,
      [...params, limit],
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    fail(res, err);
  }
});

module.exports = router;
